﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace PropertyManagementApp.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the PropertyManagementAppUser class
    public class PropertyManagementAppUser : IdentityUser
    {
    }
}
